module.exports = [
	{
		username: "Afsaran",
		password: "#Afsaran_app_pass$",
	},
];
